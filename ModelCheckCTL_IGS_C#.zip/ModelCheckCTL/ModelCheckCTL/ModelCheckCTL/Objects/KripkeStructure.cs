﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelCheckCTL.Objects
{
    public class KripkeStructure
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public KripkeStructure() 
        {
            Transitions = new List<Transition>();
            States = new List<State>();
            Atoms = new List<string>();
        }

        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="kripkeStructureDefinition"></param>
        public KripkeStructure(string kripkeStructureDefinition) : this()
        {
            try
            {
                /*PARSING*/
                List<string> parsedStructure = kripkeStructureDefinition
                    .Replace(Environment.NewLine, string.Empty)
                    .Split(new char[] { ';' }).ToList();

                if (parsedStructure == null || parsedStructure.Count != 4)
                    throw new FormatException("Input file does not contain appropriate segments to construct kripke structure");

                List<string> stateNames = parsedStructure[0]
                    .Replace(" ", string.Empty)
                    .Split(new char[] { ',' }).ToList();
                List<string> transitions = parsedStructure[1]
                    .Replace(" ", string.Empty)
                    .Split(new char[] { ',' }).ToList();
                List<string> stateAtomStructures = parsedStructure[2]
                    .Split(new char[] { ',' }).ToList();

                //load states
                foreach (string stateName in stateNames)
                {
                    State state = new State(stateName);
                    if (!States.Contains(state))
                        States.Add(new State(stateName));
                    else
                        throw new FormatException(string.Format("State {0} is defined more than once", stateName));
                }

                //load transitions
                foreach (string transition in transitions)
                {
                    List<string> parsedTransition = transition.Split(new char[] { ':' }).ToList();

                    if (parsedTransition == null || parsedTransition.Count != 2)
                        throw new FormatException("Transition is not in the valid format");

                    string transitionName = parsedTransition[0];
                    List<string> parsedFromToStates = parsedTransition[1].Split(new char[] { '-' }).ToList();

                    if (parsedFromToStates == null || parsedFromToStates.Count != 2)
                        throw new FormatException(string.Format("Transition {0} is not in [from state] - [to state] format", transitionName));

                    string fromStateName = parsedFromToStates[0];
                    string toStateName = parsedFromToStates[1];
                    State fromState = FindStateByName(fromStateName);
                    State toState = FindStateByName(toStateName);

                    if (fromState == null || toState == null)
                        throw new FormatException(string.Format("Invalid state is detected in transition {0}", transitionName));

                    Transition transitionObj = new Transition(transitionName, fromState, toState);
                    if (!Transitions.Contains(transitionObj))
                        Transitions.Add(transitionObj);
                    else
                    {
                        throw new FormatException(string.Format("Transitions from state {0} to state {1} are defined more than once"
                            , fromStateName, toStateName));
                    }
                }

                //load atoms
                foreach (string stateAtomStructure in stateAtomStructures)
                {
                    List<string> parsedStateAtomStructure = stateAtomStructure.Split(new char[] { ':' }).ToList();

                    if (parsedStateAtomStructure == null || parsedStateAtomStructure.Count != 2)
                        throw new FormatException(string.Format("{0} is not a valid state: atoms definition", stateAtomStructure));
                    string stateName = parsedStateAtomStructure[0].Replace(" ", string.Empty);
                    string atomNames = parsedStateAtomStructure[1].Trim();
                    List<string> parsedAtoms = atomNames.Split(new char[] { ' ' }).ToList();

                    List<string> stateAtoms = new List<string>();
                    foreach (string atom in parsedAtoms)
                    {
                        if(string.IsNullOrEmpty(atom))
                        {}
                        else if (!stateAtoms.Contains(atom))
                            stateAtoms.Add(atom);
                        else
                            throw new FormatException(string.Format("Atom {0} is defined more than once for state {1}"
                                , atom, stateName));
                    }

                    State stateObj = FindStateByName(stateName);
                    if (stateObj == null)
                        throw new FormatException(string.Format("State {0} is not defined", stateName));
                    stateObj.Atoms = stateAtoms;

                    //load to list of atoms
                    foreach (string atom in stateAtoms)
                    {
                        if (!Atoms.Contains(atom))
                            Atoms.Add(atom);
                    }
                }
            }
            catch (FormatException fe)
            {
                throw fe;
            }
            catch (Exception ex)
            {
                throw new FormatException("Invalid kripke input structure");
            }
        }

        public List<Transition> Transitions { get; set; }
        public List<State> States { get; set; }
        public List<string> Atoms { get; set; }

        /// <summary>
        /// Find the state by its name
        /// </summary>
        /// <param name="stateName"></param>
        /// <returns></returns>
        public State FindStateByName(string stateName)
        {
            foreach (State state in States)
            {
                if (state.StateName.Equals(stateName))
                    return state;
            }

            return null;
        }

        /// <summary>
        /// Override ToString method
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("STATES");
            sb.AppendLine("-----------");
            sb.Append(StatesToString());
            sb.AppendLine();
            sb.AppendLine();
            sb.AppendLine("TRANSITIONS");
            sb.AppendLine("-------------------");
            sb.Append(TransitionsToString());

            return sb.ToString();
        }

        public string StatesToString()
        {
            StringBuilder sb = new StringBuilder();

            List<string> stateStrings = new List<string>();
            foreach (State state in States)
            {
                string atomNames = string.Join(", ", state.Atoms.ToArray());
                stateStrings.Add(string.Format("{0}({1})", state.StateName, atomNames));
            }

            sb.Append(string.Join(", ", stateStrings.ToArray()));
            return sb.ToString();
        }

        public string TransitionsToString()
        {
            StringBuilder sb = new StringBuilder();

            List<string> transitionString = new List<string>();
            foreach (Transition transition in Transitions)
            {
                transitionString.Add(string.Format("{0}({1} -> {2})", transition.TransitionName
                    , transition.FromState.StateName, transition.ToState.StateName));
            }

            sb.Append(string.Join(", ", transitionString.ToArray()));
            return sb.ToString();
        }
    }
}
