﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelCheckCTL.Objects
{
    public class Transition : IEquatable<Transition>
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public Transition() { }

        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="fromState"></param>
        /// <param name="toState"></param>
        public Transition(State fromState, State toState)
            : this()
        {
            TransitionName = string.Empty;
            FromState = fromState;
            ToState = toState;
        }

        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="transitionName"></param>
        /// <param name="fromState"></param>
        /// <param name="toState"></param>
        public Transition(string transitionName, State fromState, State toState) : this()
        {
            TransitionName = transitionName;
            FromState = fromState;
            ToState = toState;
        }

        public string TransitionName { get; set; }
        public State FromState { get; set; }
        public State ToState { get; set; }

        /// <summary>
        /// Implement Equals method
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(Transition other)
        {
            if (this.FromState.Equals(other.FromState) && this.ToState.Equals(other.ToState))
                return true;

            return false;
        }
    }
}
