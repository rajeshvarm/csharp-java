﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelCheckCTL.Objects
{
    public class State : IEquatable<State>
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public State() 
        {
            Atoms = new List<string>();
        }

        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="stateName"></param>
        public State(string stateName) : this()
        {
            StateName = stateName;
        }

        public string StateName { get; set; }
        public List<string> Atoms { get; set; }

        /// <summary>
        /// Implement Equals method
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(State other)
        {
            return this.StateName.Equals(other.StateName);
        }
    }
}
