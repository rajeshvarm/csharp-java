﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using ModelCheckCTL.Objects;

namespace ModelCheckCTL
{
    public partial class Main : Form
    {
        private KripkeStructure _kripke;
        public Main()
        {
            InitializeComponent();
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            try
            {
                if (_kripke == null)
                {
                    MessageBox.Show("Please load Kripke model", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string originalExpression = this.textBoxCTLFormula.Text;
                string expression = originalExpression.Replace(" ", string.Empty);
                string checkedStateID = this.comboBoxState.SelectedItem.ToString();

                State checkedState = new State(checkedStateID);

                CtlFormula ctlFormula = new CtlFormula(expression, checkedState, this._kripke);
                bool isSatisfy = ctlFormula.IsSatisfy();

                string message = GetMessage(isSatisfy, originalExpression, checkedStateID);
                this.textBoxCheckResult.Text = message;
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.Message, "CTL syntax error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace, "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public string GetMessage(bool isSatisfy, string expression, string stateID)
        {
            string message = string.Format("Property {0} {1} in state {2}"
                , expression
                , isSatisfy ? "holds" : "does not hold"
                , stateID);

            return message;
        }

        private void loadModelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //open file 
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.DefaultExt = ".txt";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            if (DialogResult.OK != openFileDialog.ShowDialog())
                return;

            Reset();

            try
            {
                string inputFileName = openFileDialog.FileName;
                string kripkeString = File.ReadAllText(inputFileName);

                KripkeStructure kripke = new KripkeStructure(kripkeString);
                _kripke = kripke;

                //display loaded kripke
                this.groupBoxModel.Text = System.IO.Path.GetFileName(openFileDialog.FileName);
                this.textBoxModelDescription.Text = _kripke.ToString();

                //fill state combo box
                foreach (State state in _kripke.States)
                {
                    comboBoxState.Items.Add(state.StateName);
                }
                comboBoxState.SelectedIndex = 0;
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.Message, "CTL syntax error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace, "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Reset()
        {
            this.comboBoxState.Items.Clear();
            this.textBoxCTLFormula.Text = string.Empty;
            this.textBoxCheckResult.Text = string.Empty;
            this.groupBoxModel.Text = "Model";
            this.textBoxModelDescription.Text = string.Empty;
            this._kripke = null;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
